import 'package:flutter/material.dart';

void main() {
  runApp(const AppleMobile());
}

class AppleMobile extends StatelessWidget {
  const AppleMobile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Image(
                      width: 50, height: 50, image: AssetImage('assets/apple.png')),
                  const SizedBox(
                    width: 5,
                  ),
                  Column(
                    children: const [
                      Text('Apple',
                          style: TextStyle(fontSize: 17, fontFamily: 'Pacifico')),
                      Text('Phone',
                          style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Pacifico',
                              color: Colors.orange)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 35,),
              const Text('Login',
                  style: TextStyle(
                      fontSize: 40,
                      fontFamily: 'Pacifico',
                      color: Colors.orange)),
              const SizedBox(height: 5,),
              const Text(
                textAlign: TextAlign.center,
                'The iPhone is a smartphone made by Apple \n'
                  'that combines a computer,iPod, digital camera \n'
                  'and cellular phone into one device with a \n'
                  'touchscreen interface', style: TextStyle(
                fontSize: 10, fontFamily: 'Pacifico', color: Colors.black45,
              ),),
              const SizedBox(height: 30,),
              SizedBox(
                width: 300,
                child: TextFormField(
                  decoration: InputDecoration(
                    fillColor: Colors.orange.shade50,
                    filled: true,
                    hintText: 'Email',
                    hintStyle: const TextStyle(
                      color: Colors.orange,
                    ),
                    labelText: 'Email',
                    labelStyle: const TextStyle(
                      color: Colors.orange,
                    ),
                    focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.orange,

                        )
                    ),
                    prefixIcon: const Icon(Icons.email, color: Colors.orange),
                    border:OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              SizedBox(
                width: 300,
                child: TextFormField(
                  decoration: InputDecoration(
                    fillColor: Colors.orange.shade50,
                    filled: true,
                    hintText: 'Password',
                    hintStyle: const TextStyle(
                      color: Colors.orange,
                    ),
                    labelText: 'Password',
                    labelStyle: const TextStyle(
                      color: Colors.orange,
                    ),
                    focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.orange,

                        )
                    ),
                    prefixIcon: const Icon(Icons.lock, color: Colors.orange),
                    suffixIcon: const Icon(Icons.visibility_off, color: Colors.orange),
                    border:OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 160),
                child: GestureDetector(
                  onTap: (){
                  },
                  child: const Text('Forget Password', style: TextStyle(
                    fontSize: 20, fontFamily: 'Pacifico', color: Colors.orange,
                    decoration: TextDecoration.underline,
                  ),),
                ),
              ),
              const SizedBox(height: 40,),
              Container(
                height: 35,
                width: 150,
                child: const Center(
                  child: Text('Login',  style: TextStyle(
                    fontSize: 20, fontFamily: 'Pacifico', color: Colors.white,
                  )),
                ),
                decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: const [
                    Text('Dont have account? ' ,  style: TextStyle(
                    fontSize: 20, fontFamily: 'Pacifico', color: Colors.black,
                  )),
                  Text('Sigin up',  style: TextStyle(
                    fontSize: 20, fontFamily: 'Pacifico', color: Colors.orange,
                  )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
