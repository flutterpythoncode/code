<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>imageSteganographyLoginForm</title>
    <!-- Code Style Css-->
    <link rel="stylesheet" href="style.css">
    <!-- Code Sweet Alert Box-->
    <link href="http://fonts.cdnfonts.com/css/sweet" rel="stylesheet">
    <!-- Code Font-->
    <style>
        @import url('http://fonts.cdnfonts.com/css/Cursive');
    </style>
    <!-- Code Image Steganography Logo-->
        <style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body{
        background: black;
        display: flex;
        justify-content: center;
        align-items: center;
        align-content: center;
        min-height: 100vh;
    }
    .text-effect{
        overflow: hidden;
        position: relative;
        filter: contrast(110%) brightness(190%);
    }
    .neon{
        position: relative;
        background: black;
        color: transparent;
    }
    .neon::before,
    .neon::after{
        content: attr(data-text);
        color: white;
        filter: blur(0.02em);
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
    }
    .neon::after{
        mix-blend-mode: difference;
    }
    .gradient,
    .spotlight{
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        pointer-events: none;
        z-index: 10;
    }
    .gradient{
        background: linear-gradient(45deg, #099BF3, blue);
        mix-blend-mode: multiply;
    }
    .spotlight{
        animation: light 5s infinite linear;
        background: radial-gradient(circle, white, transparent 25%) 0 0/25% 25%, radial-gradient(circle, white, black 25%);
        top: -100%;
        left: -100%;
        mix-blend-mode: color-dodge;
    }
    .neon{
        font: 80 35px "Lato", sans-serif;
        text-transform: uppercase;
        text-align: center;
        margin: 0;
    }
    .neon:focus{
        outline: none;
        border: 1px dotted white;
    }
    @keyframes light {
        100%{
            transform: translate3d(50%, 50%, 0);
        }
    }
    .class{
        margin-left: 20px;
    }
</style> 
</head>
<body onload = "slider()">
<!-- Code Banner-->
    <div class="banner">
        <!-- Code Slider-->
        <div class="slider">
            <img src="b1.jpg" id="slideImage">
        </div>
        <!-- Code Border Image Steganography Logo-->
        <div class="overlay">
            <div class="logos">   
                <img src="binary3.png">
                <div style="border:5px solid #099BF3; text-align:center;width: 36%; border-radius:15px; height: 50px;margin-left: 441px">                             
                <div class="class">
                <div class="text-effect">
                    <h1 class="neon" data-text="Image Steganography" contenteditable>Image Steganography</h1>
                    <div class="gradient"></div>
                    <div class="spotlight"></div>
                </div>
                </div>  
            </div>
            <!-- Code Border-->
            <div class="container">
            <div style="border:5px solid #099BF3; text-align:center; width:36%; border-radius:15px; margin-top: 10px;margin-left: 441px; height: 400px">   
            <div class="login-box">
            <div class="row">
            <div class="col-md-16">
                <!-- Code Logo-->  
                <h2>Registration Here</h2>
                <div class="regis">
                    <img src="reg.png">
                </div>
                <!-- Code Frame-->
                <form action="registration.php" method="post">
                    <div class="form-group">
                        <label>User Name</label>
                        <input type="text" name="user" class="form-control" require , placeholder="  Enter your name",>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" require, placeholder="  Enter your password">
                    </div>
                    <button type="submit" class="button">Registration</button> <!-- btn btn-primary -->
                </form>
            </div> 
            </div>   
        </div>

            
    </div>
<!-- Code Slider Image-->
    <script>
        var slideImage = document.getElementById("slideImage");
        var images = new Array(
            "b5.jpg",
            "b7.jpg",
            "b16.jpg",
            "b24.jpg",
            "b26.jpg",
            "b27.jpg",
            "b28.jpg",
            "b29.jpg",
            "b30.jpg",
            "b31.jpg",
            "b33.jpg",
            "b34.jpg",
            "b35.jpg",
            "b36.jpg",
            
        );
        var len = images.length;
        var i=0;
        function slider() {
            if(i > len-1)
            {
                i = 0;
            }
            slideImage.src = images[i];
            i++;
            setTimeout('slider()', 3000);
        }
    </script> 
    <?php include('footer.php') ?>
</body>
<!-- Code Image Steganography Logo-->
<script>
    $('[data-text]').on('keyup', function () {
        $(this).attr('data-text', $(this).text());
    });
</script>
</html>