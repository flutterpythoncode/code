<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered successfully</title>
    <!-- Code Sweet Alert box-->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Code Style Css-->
    <link rel="stylesheet" href="style.css">
    <!-- Code Button -->
    <style>
        .button {
            display: inline-block;
            border-radius: 10px;
            background-color: transparent;
            border: 099BF3;
            color: #FFFFFF;
            text-align: center;
            font-size: 15px;
            padding: 12px;
            width: 130px;
            transition: all 0.5s;
            cursor: pointer;
            margin: 5px;
        }

        .button span {
            cursor: pointer;
            display: inline-block;
            position: relative;
            transition: 0.5s;
        }

        .button span:after {
            content: '\226A';
            position: absolute;
            opacity: 0;
            top: 0;
            left: -105px;
            transition: 0.5s;
        }

        .button:hover span {
            padding-right: 25px;
        }

        .button:hover span:after {
            opacity: 1;
            right: 0;
        }
    </style>
<!-- Code Image Steganography Logo-->
    <style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body{
        background: black;
        display: flex;
        justify-content: center;
        align-items: center;
        align-content: center;
        min-height: 100vh;
    }
    .text-effect{
        overflow: hidden;
        position: relative;
        filter: contrast(110%) brightness(190%);
    }
    .neon{
        position: relative;
        background: black;
        color: transparent;
    }
    .neon::before,
    .neon::after{
        content: attr(data-text);
        color: white;
        filter: blur(0.02em);
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
    }
    .neon::after{
        mix-blend-mode: difference;
    }
    .gradient,
    .spotlight{
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        pointer-events: none;
        z-index: 10;
    }
    .gradient{
        background: linear-gradient(45deg, #099BF3, blue);
        mix-blend-mode: multiply;
    }
    .spotlight{
        animation: light 5s infinite linear;
        background: radial-gradient(circle, white, transparent 25%) 0 0/25% 25%, radial-gradient(circle, white, black 25%);
        top: -100%;
        left: -100%;
        mix-blend-mode: color-dodge;
    }
    .neon{
        font: 80 35px "Lato", sans-serif;
        text-transform: uppercase;
        text-align: center;
        margin: 0;
    }
    .neon:focus{
        outline: none;
        border: 1px dotted white;
    }
    @keyframes light {
        100%{
            transform: translate3d(50%, 50%, 0);
        }
    }
    .class{
        margin-left: 20px;
    }
</style>
</head>
<body class="black">
<!-- Code Logo-->
<div class="slider">
    <img style="width:100px; height:100px;margin-top: 160px;margin-left: 630px;" src="succ.png">
</div>
<!-- Code Border Image Stegnaography Logo-->
<div style="border:5px solid #099BF3; text-align:center;width: 36%; border-radius:15px; height: 50px; margin-bottom: 400px;">                              
<div class="class">
<div class="text-effect">
    <h1 class="neon" data-text="Image Stegnaography" contenteditable>Image Stegnaography</h1>
    <div class="gradient"></div>
    <div class="spotlight"></div>
</div>
</div>
<!-- Code Paragraph-->
<p style="color:#8c8c89; font-family:Monospace; font-size: 21px;margin-top: 200px;">
        You are successfully registered  </p>           
<p style="color:#8c8c89; font-family:Monospace; font-size: 15px;">
        Your record saved in database</p>
<p style="color:#8c8c89; font-family:Monospace; font-size: 15px;"> 
        Click button for go to login page ....  </p>
<!-- Code Alert Box-->
<script>
    Swal.fire({
    icon: 'success',
    title: 'Image Steganogrphy Login',
    text: 'Successfully Registered.',
    timer: 2000
    });
</script>
<!-- Code Button Function-->
<?php
    if(array_key_exists('read', $_POST))
    {
        button();
    }
    function button()
    {
        echo "<script>window.location.href='imageSteganographyLoginForm.php';</script>";
    }
?>
<!-- Code Button-->
<form method="post">
    <button class="button" style="vertical-align:middle;margin-top: 50px" type="submit" name="read" value="click" ><span>LOGIN FORM</span>
    </button>
</form>
</body>
<!-- Code Button-->
<script>
    $('[data-text]').on('keyup', function () {
        $(this).attr('data-text', $(this).text());
    });
</script>
</html>
