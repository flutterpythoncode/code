<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <!-- Code Sweet Alert-->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
 
<?php 
// Session Start
session_start();
// Code DB
$con = mysqli_connect('localhost', 'root', '');
mysqli_select_db($con, 'userregistration');

$name = $_POST['user'];
$pass = $_POST['password'];

$s = "select * from usertable where name = '$name'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

if(empty($_POST['user']) && empty($_POST['password']))
{
    header('location:namepassfield.php');
}
elseif(empty($_POST['password']))
{
    header('location:passfield.php');
}
elseif(empty($_POST['user']))
{
    header('location:namefield.php');
}
elseif($num == 1)
{
    header('location:allready.php');
}
else
{
    $reg = "insert into usertable(name, password) values('$name', '$pass')";
    mysqli_query($con, $reg);
    header('location:succregis.php');

}
?>
<?php include('footer.php') ?>
</body>
</html>
