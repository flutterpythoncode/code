<?php
//Code session start and destroy
session_start();
session_destroy();
//Code header go to next page
header('location:loginAndRegisterform.php');

?>