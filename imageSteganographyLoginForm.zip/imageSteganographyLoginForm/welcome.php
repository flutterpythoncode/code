<?php
session_start();
if(!isset($_SESSION['username']))
{
    header('location:location:loginAndRegisterform.php');
}
?>

<html>
<head>

    <title>Welcome image steganography</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!-- Code Image Steganography-->
    <style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body{
        background: black;
        display: flex;
        justify-content: center;
        align-items: center;
        align-content: center;
        min-height: 100vh;
    }
    .text-effect{
        overflow: hidden;
        position: relative;
        filter: contrast(110%) brightness(190%);
    }
    .neon{
        position: relative;
        background: black;
        color: transparent;
    }
    .neon::before,
    .neon::after{
        content: attr(data-text);
        color: white;
        filter: blur(0.02em);
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
    }
    .neon::after{
        mix-blend-mode: difference;
    }
    .gradient,
    .spotlight{
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        pointer-events: none;
        z-index: 10;
    }
    .gradient{
        background: linear-gradient(45deg, #099BF3, blue);
        mix-blend-mode: multiply;
    }
    .spotlight{
        animation: light 5s infinite linear;
        background: radial-gradient(circle, white, transparent 25%) 0 0/25% 25%, radial-gradient(circle, white, black 25%);
        top: -100%;
        left: -100%;
        mix-blend-mode: color-dodge;
    }
    .neon{
        font: 80 35px "Lato", sans-serif;
        text-transform: uppercase;
        text-align: center;
        margin: 0;
    }
    .neon:focus{
        outline: none;
        border: 1px dotted white;
    }
    @keyframes light {
        100%{
            transform: translate3d(50%, 50%, 0);
        }
    }
    .class{
        margin-left: 20px;
    }
</style>
</head>
<body class="black">
<div style="margin-left: 100px">
    <h1> welcome <?php echo $_SESSION['username']; ?> </h1>
</div>   
<!-- Code Border-->
<div style="border:5px solid #099BF3; text-align:center;
                            width: 30%; border-radius:15px; height: 150px; margin-bottom: 400px;margin-left: -320px"> 
<img style="width:30px; height:30px;margin-top: 10px;margin-left: 0px;" src="binary3.png">                              
<div class="class">
<div class="text-effect">
    <h1 class="neon" data-text="Image Stegnaography" contenteditable>Image Stegnaography</h1>
    <div class="gradient"></div>
    <div class="spotlight"></div>
</div>
</div>
<!-- Code Alert Box-->
<script type="text/javascript">
    $(document).ready(function() {
        swal({
            title: "Suceessfully Login",
            text: "Image Steganography",
            icon: "success",
            button: "Ok",
            timer: 2000
        });
    });
</script>
<!-- Code Paragraph-->
<p style="margin-top: 280px">ABOUT IMAGE STEGANOGRAPHY <br>Image Steganography is the process of hiding information which can be text
      inside a cover image. <br>The secret information is hidden in 
    a way that it not visible to the human eyes.</p>

</body>
<!-- Code Button-->
<script>
    $('[data-text]').on('keyup', function () {
        $(this).attr('data-text', $(this).text());
    });
</script>

</html>